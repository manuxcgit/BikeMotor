# Powerino
$13 open source/hardware DIY bicycle power meter. See https://github.com/rrrlasse/powerino/wiki
