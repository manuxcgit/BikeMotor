package com.powerino.prototype;

public interface IFragmentToActivity {
    void showToast(String msg);

    void communicateToFragment2();
}